#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <Intel_Edison_BT_SPP.h>

using namespace std;


int Intel_Edison_BT_SPP::open() {

	int a = openRead() ;
	int b = openWrite() ;

	return 1 ;
}

int Intel_Edison_BT_SPP::openRead() {

	if (_fd != -1)
		close(_fd);

	// FIFO file �б� ���� ���� ( ����Ʈ������ ���� �����͸� �е��� )
	_fd = ::open( _pipeName, O_RDONLY | O_NONBLOCK ) ;

	if (_fd == -1) {
		// perror("Cannot open file\n");
		// printf("errno %s\n", strerror(errno));
		// Serial.print("open error : "); Serial.println(strerror(errno));
		return -1;
	}

	return 1;
}


int Intel_Edison_BT_SPP::openWrite() {

	if ( _fd2 != -1 ) close( _fd2 ) ;

	// FIFO file ���� ���� ���� ( ����Ʈ���� ���� �����͸� ������ )
	_fd2 = ::open( _pipeName2, O_WRONLY ) ;

	if ( _fd2 == -1 ) {
		// perror("Cannot open Write file\n");
		// printf("errno %s\n", strerror(errno));
		// Serial.print("open error2 : "); Serial.println(strerror(errno));
		return -1;
	}

	return 1;

}


ssize_t Intel_Edison_BT_SPP::read() {

	memset(_buf,0,MAX_BUF);
	memset(_valuebuf,0,MAX_BUF);

	if (_fd == -1)
		openRead();

	// fd(= pipe_out )���� �о�� �����͸� buf�� ����
	ssize_t size = ::read(_fd, _buf, MAX_BUF-1);


	if (size == -1) {
		// perror("Read error\n");
		// printf("errno %s\n", strerror(errno));
		// Serial.print("read error : ");
		// Serial.println(strerror(errno));

		return -1 ;

	}

	// ���ɾ� ����
	mMode = 0 ;

	if ( _buf[size-2]=='/' && _buf[size-1]=='C' ) {
		mMode = MODE_CONTROL;
		_buf[size-2] = 0 ;
	}
	else if ( _buf[size-2]=='/' && _buf[size-1]=='S' ) {
		mMode = MODE_SENSOR ;
		_buf[size-2] = 0 ;
	}
	else {
		mMode = MODE_NOTHING ;
		_buf[size] = 0 ;
	}


	// ���ɾ� ����ϰ��, ���ɾ�� ������ �Ǵٸ� �����Ͱ� ���۵Ǿ����� Ȯ��
	if ( mMode != MODE_NOTHING && strchr(_buf, ' ') > 0 ) {
		//char tmp[MAX_BUF] ;
		//strcpy( tmp, _buf );
		char * divided ;

		divided = strtok( _buf, " " );
		divided = strtok( NULL, " " );
		snprintf( _valuebuf, sizeof(_valuebuf), "%s", divided );

	}

	return size ;

}


ssize_t Intel_Edison_BT_SPP::writeData( float sendData ) {

	memset(_sendbuf,0x00,MAX_BUF);

	if ( _fd2 == -1 )
		openWrite();

	snprintf( _sendbuf, sizeof(_sendbuf), "%g", sendData );


	ssize_t size = ::write( _fd2, _sendbuf, MAX_BUF-1 );

	if (size == -1) {
		perror("Write error\n");
		printf("errno %s\n", strerror(errno));
		Serial.print("Write error : "); Serial.println(strerror(errno));
	}

	return size ;	// size = the number of bytes written

}

ssize_t Intel_Edison_BT_SPP::writeMessage( char* sendData ) {

	memset(_sendbuf,0x00,MAX_BUF);

	if ( _fd2 == -1 )
		openWrite();

	snprintf( _sendbuf, sizeof(_sendbuf), "%s", sendData );


	ssize_t size = ::write( _fd2, _sendbuf, MAX_BUF-1 );

	if (size == -1) {
		perror("Write error\n");
		printf("errno %s\n", strerror(errno));
		Serial.print("Write error : "); Serial.println(strerror(errno));
	}

	return size ;	// size = the number of bytes written

}

const int Intel_Edison_BT_SPP::getMode() {
	return mMode ;
}

const char * Intel_Edison_BT_SPP::getSendBuf() {
	return _sendbuf ;
}

const char * Intel_Edison_BT_SPP::getBuf() {
	return _buf;
}

const char * Intel_Edison_BT_SPP::getValueBuf() {
	return _valuebuf;
}

void Intel_Edison_BT_SPP::setCommand( char* com ){
	mCommand = com ;
}

Intel_Edison_BT_SPP::~Intel_Edison_BT_SPP() {
	if (_fd != -1) {
		close (_fd);
		_fd = -1;
	}
}
