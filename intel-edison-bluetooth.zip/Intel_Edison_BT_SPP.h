#ifndef _INTEL_EDISON_BT_SPP_H_
#define _INTEL_EDISON_BT_SPP_H_

#if ARDUINO >= 100
 #include "Arduino.h"
#else
 #include "WProgram.h"
#endif

#define MAX_BUF 2048

const int MODE_CONTROL = 2 ;
const int MODE_SENSOR = 1 ;
const int MODE_NOTHING = -1 ;

class Intel_Edison_BT_SPP {

	public:
	int open();
	int openRead() ;
	int openWrite();

	int read();
	ssize_t writeData( float sendData );
	ssize_t writeMessage( char* sendData );

	const int getMode();
	const char * getSendBuf();
	const char * getBuf();
	const char * getValueBuf();

	void setCommand( char* com );

	~Intel_Edison_BT_SPP();

	private:

	int mMode;
	char* mCommand;

	int _fd = -1;
	const char * _pipeName = "/tmp/arduino_pipe_out";
	char _buf[MAX_BUF];
	char _valuebuf[MAX_BUF];
	
	int _fd2 = -1 ;
	const char * _pipeName2 = "/tmp/arduino_pipe_in" ;
	char _sendbuf[MAX_BUF];
	
};

#endif
